package com.finalroundDemo9519.App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZDemo1995ApplicationTests {

	@Test
	void contextLoads() {
	}

}
