package com.finalroundDemo9519.App.services;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.finalroundDemo9519.App.model.Demo1995;
import com.finalroundDemo9519.App.repository.Demo1995Repository;

@Service
public class Demo1995ServiceImpl
    implements Demo1995Services {
   
    @Autowired private Demo1995Repository todoRepo;
    
    @Override
	public List<Demo1995> getAlltodoList() {
		return todoRepo.findAll();
	}

	@Override
	public void save(Demo1995 todo) {
		todoRepo.save(todo);
	}
 
    @Override public Demo1995 getById(Long id)
    {
        Optional<Demo1995> optional = todoRepo.findById(id);
        Demo1995 todo = null;
        if (optional.isPresent())
            todo = optional.get();
        else
            throw new RuntimeException(
                "todo list not found for id : " + id);
        return todo;
    }
 
    @Override public void deleteViaId(long id)
    {
        todoRepo.deleteById(id);
    }

	
}