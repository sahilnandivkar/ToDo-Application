package com.finalroundDemo9519.App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZDemo1995Application {

	public static void main(String[] args) {
		SpringApplication.run(ZDemo1995Application.class, args);
	}

}
