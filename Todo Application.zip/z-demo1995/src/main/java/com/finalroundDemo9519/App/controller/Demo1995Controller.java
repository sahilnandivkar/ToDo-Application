package com.finalroundDemo9519.App.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.finalroundDemo9519.App.model.Demo1995;
import com.finalroundDemo9519.App.services.Demo1995ServiceImpl;

@Controller
public class Demo1995Controller {
 
    @Autowired
    private Demo1995ServiceImpl demo1995ServiceImpl;
 
    @GetMapping("/")
    public String viewHomePage(Model model) {
        model.addAttribute("alltodolist", demo1995ServiceImpl.getAlltodoList());
        return "index";
    }
 
    @GetMapping("/addnew")
    public String addNewTodo(Model model) {
        Demo1995 todo = new Demo1995();
        model.addAttribute("todo", todo);
        return "newtodo";
    }
 
    @PostMapping("/save")
    public String save(@ModelAttribute("employee") Demo1995 todo) {
    	demo1995ServiceImpl.save(todo);
        return "redirect:/";
    }
 
    @GetMapping("/showFormForUpdate/{id}")
    public String updateForm(@PathVariable(value = "id") long id, Model model) {
        Demo1995 todo =demo1995ServiceImpl.getById(id);
        model.addAttribute("todo", todo);
        return "update";
    }
 
    @GetMapping("/deletetodo/{id}")
    public String deleteThroughId(@PathVariable(value = "id") long id) {
    	demo1995ServiceImpl.deleteViaId(id);
        return "redirect:/";
 
    }
}