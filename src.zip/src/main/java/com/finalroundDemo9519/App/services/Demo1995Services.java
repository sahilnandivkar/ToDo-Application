package com.finalroundDemo9519.App.services;

import java.util.List;
import com.finalroundDemo9519.App.model.Demo1995;

public interface Demo1995Services {
	  List<Demo1995> getAlltodoList();
	    void save(Demo1995 todo);
	    Demo1995 getById(Long id);
	    void deleteViaId(long id);
}
