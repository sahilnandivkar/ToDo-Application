package com.finalroundDemo9519.App.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.finalroundDemo9519.App.model.Demo1995;

@Repository
public interface Demo1995Repository extends JpaRepository<Demo1995,Long> {
 
}
